console.log('Importing scripts');

import '/src/background/updateNotifier.js';
import '/src/background/badge.js';
import '/src/background/cafeLoader.js';
